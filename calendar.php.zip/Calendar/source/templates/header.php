<br><br>
<p align=center>Use <b>admin/admin</b> to login. This header can be found in Header item on the Editor screen.</p>